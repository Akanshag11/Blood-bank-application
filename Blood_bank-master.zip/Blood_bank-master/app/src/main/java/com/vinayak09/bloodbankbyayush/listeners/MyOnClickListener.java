package com.vinayak09.bloodbankbyayush.listeners;

public interface MyOnClickListener {
    void getPosition(int position);
}
